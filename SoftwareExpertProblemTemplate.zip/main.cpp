#include <iostream>

#include "../inputGenerator/hwsInputGenerator.h"

int main(void) {
	//WORK HERE
	std::cout << "template project\n";
	std::shared_ptr<hws::DataType> spInputData;
	hws::generateInputs(spInputData);



	return 0;
}